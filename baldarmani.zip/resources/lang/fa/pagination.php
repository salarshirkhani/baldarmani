<?php

return [
    'next'     => 'بعدی &raquo;',
    'previous' => '&laquo; قبلی',
];
