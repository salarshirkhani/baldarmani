<x-sidebar-item title="داشبورد" icon="fas fa-tachometer-alt" route="dashboard.customer.index" />
<x-sidebar-item title="ایجاد درخواست مشاوره" icon="fas fa-plus" route="dashboard.customer.consultant.create" />
<x-sidebar-item title=" درخواست های مشاوره" icon="fas fa-bars" route="dashboard.customer.consultant.manage" />
