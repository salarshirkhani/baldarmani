<x-sidebar-item title="داشبورد" icon="fas fa-tachometer-alt" route="dashboard.owner.index" />

