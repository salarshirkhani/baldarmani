<x-sidebar-item title="داشبورد" icon="fas fa-tachometer-alt" route="dashboard.admin.index" />
<x-sidebar-item title="مدیریت محصولات" icon="fas fa-plus" route="dashboard.admin.product.manage" />
<x-sidebar-item title="لیست دسته‌بندی محصولات" icon="fas fa-folder" route="dashboard.admin.categories.index" />
<x-sidebar-item title="افزودن دسته‌بندی محصولات" icon="fas fa-plus" route="dashboard.admin.categories.create" />
<x-sidebar-item title="مدیریت مطالب" icon="fas fa-plus" route="dashboard.admin.news.manage" />
<x-sidebar-item title="لیست دسته‌بندی‌ مقالات" icon="fas fa-folder" route="dashboard.admin.postcategories.index" />
<x-sidebar-item title="مدیریت مشاوره" icon="fas fa-folder" route="dashboard.admin.consultant.manage" />
<x-sidebar-item title="گزارشات خرید" icon="fas fa-bars" route="" />
